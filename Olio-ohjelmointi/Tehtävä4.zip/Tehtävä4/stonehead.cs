﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tehtävä4
{
    class Kappale
    {
        public string Nimi;
        public string Pituus;

        public Kappale(string _nimi, string _pituus)
        {
            Nimi = _nimi;
            Pituus = _pituus;
        }
    }
}
